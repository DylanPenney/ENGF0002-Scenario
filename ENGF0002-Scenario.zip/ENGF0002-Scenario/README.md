# ENGF0002-Scenario

As first-year Computer Science students, we all needed an extent of extra support for Conditional Probability understanding during the first term. We used 
textbooks and attended problem classes to practise questions and extend our knowledge. Although these were helpful, our aim is to design a program with the 
ability of taking input (operators, values) to create plenty of different practice questions and display visual (shaded Venn Diagram) output to enhance 
understanding. Our target audience is Sixth Form Computer Science and Mathematics students to reinforce their Conditional Probability knowledge and prepare 
them for their exams.
